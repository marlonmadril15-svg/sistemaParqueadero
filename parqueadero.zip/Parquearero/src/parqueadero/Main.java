package parqueadero;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.FlowLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.BorderFactory;

// Ventana principal. Aqui se registra la entrada de los carros.
public class Main extends JFrame {

    private Parqueadero registroParqueadero;
    private JTextField campoPlaca;
    private JTextField campoConductor;
    private VentanaCarros ventanaVehiculos;

    public Main() {
        registroParqueadero = new Parqueadero();

        setTitle("Parqueadero | Control de ingreso");
        setSize(560, 330);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        crearPantalla();
    }

    private void crearPantalla() {
        Color azulPrincipal = new Color(31, 78, 121);
        Color fondoClaro = new Color(242, 247, 252);
        getContentPane().setBackground(fondoClaro);

        JPanel datos = new JPanel(new GridLayout(2, 2, 12, 14));
        datos.setBackground(fondoClaro);
        datos.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createTitledBorder("Registrar entrada"),
                BorderFactory.createEmptyBorder(16, 18, 16, 18)));

        datos.add(new JLabel("Placa:"));
        campoPlaca = new JTextField();
        datos.add(campoPlaca);

        datos.add(new JLabel("Conductor:"));
        campoConductor = new JTextField();
        datos.add(campoConductor);

        JButton botonEntrada = new JButton("Guardar entrada");
        botonEntrada.addActionListener(e -> guardarEntrada());

        JButton botonVerCarros = new JButton("Ver carros dentro");
        botonVerCarros.addActionListener(e -> abrirCarros());

        JButton botonSalida = new JButton("Salida (ingresar horas)");
        botonSalida.addActionListener(e -> abrirSalida());

        JPanel botones = new JPanel();
        botones.setBackground(fondoClaro);
        botones.setBorder(BorderFactory.createEmptyBorder(0, 10, 16, 10));
        botones.add(botonEntrada);
        botones.add(botonVerCarros);
        botones.add(botonSalida);
        getContentPane().add(datos, BorderLayout.CENTER);
        getContentPane().add(botones, BorderLayout.SOUTH);
    }

    private void guardarEntrada() {
        String numeroPlaca = campoPlaca.getText().trim();
        String nombreConductor = campoConductor.getText().trim();

        if (numeroPlaca.isEmpty() || nombreConductor.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Escriba la placa y el conductor.");
            return;
        }

        JOptionPane.showMessageDialog(this, registroParqueadero.agregarCarro(numeroPlaca, nombreConductor));
        actualizarCarros();
        campoPlaca.setText("");
        campoConductor.setText("");
    }

    private void abrirCarros() {
        if (ventanaVehiculos == null) {
            ventanaVehiculos = new VentanaCarros(registroParqueadero);
        }

        ventanaVehiculos.actualizarLista();
        ventanaVehiculos.setVisible(true);
    }

    private void abrirSalida() {
        VentanaSalida ventanaSalida = new VentanaSalida(registroParqueadero, this);
        ventanaSalida.setVisible(true);
    }

    public void actualizarCarros() {
        if (ventanaVehiculos != null) {
            ventanaVehiculos.actualizarLista();
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            Main ventana = new Main();
            ventana.setVisible(true);
        });
    }
}
