package parqueadero;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

// Aqui se guarda la lista de carros y se hacen las operaciones.
public class Parqueadero {

    private ArrayList<Vehiculo> vehiculosDentro;
    private final double TARIFA_POR_HORA = 0.50;

    public Parqueadero() {
        vehiculosDentro = new ArrayList<Vehiculo>();
        crearArchivos();
    }

    // Crea los dos archivos que pide el deber.
    private void crearArchivos() {
        try {
            File archivoVehiculos = new File("vehiculos.txt");
            File archivoCaja = new File("caja.txt");

            if (!archivoVehiculos.exists()) {
                FileWriter escritorVehiculos = new FileWriter(archivoVehiculos);
                escritorVehiculos.write("REGISTRO DE VEHICULOS\n");
                escritorVehiculos.close();
            }

            if (!archivoCaja.exists()) {
                FileWriter escritorCaja = new FileWriter(archivoCaja);
                escritorCaja.write("REGISTRO DE CAJA\n");
                escritorCaja.close();
            }
        } catch (IOException error) {
            System.out.println("No se pudieron crear los archivos.");
        }
    }

    public String agregarCarro(String numeroPlaca, String nombreConductor) {
        numeroPlaca = numeroPlaca.toUpperCase();

        if (buscarCarro(numeroPlaca) != null) {
            return "Ese carro ya esta dentro del parqueadero.";
        }

        Vehiculo nuevoVehiculo = new Vehiculo(numeroPlaca, nombreConductor);
        vehiculosDentro.add(nuevoVehiculo);
        guardarVehiculo("ENTRADA: " + numeroPlaca + " - " + nombreConductor);

        return "Entrada guardada\nPlaca: " + numeroPlaca;
    }

    public String sacarCarro(String numeroPlaca, double horasUsadas) {
        numeroPlaca = numeroPlaca.toUpperCase();
        Vehiculo vehiculoEncontrado = buscarCarro(numeroPlaca);

        if (vehiculoEncontrado == null) {
            return "No se encontro ese carro.";
        }

        int horasCobradas = (int) Math.ceil(horasUsadas);
        double totalPagar = horasCobradas * TARIFA_POR_HORA;

        vehiculosDentro.remove(vehiculoEncontrado);
        guardarVehiculo("SALIDA: " + numeroPlaca + " - " + horasUsadas + " horas");
        guardarCaja(numeroPlaca + " - Total pagado: $" + String.format("%.2f", totalPagar));

        return "SALIDA DEL CARRO\n\nPlaca: " + numeroPlaca
                + "\nHoras cobradas: " + horasCobradas
                + "\nTotal a pagar: $" + String.format("%.2f", totalPagar);
    }

    public String verCarros() {
        if (vehiculosDentro.isEmpty()) {
            return "No hay carros dentro del parqueadero.";
        }

        String listaVehiculos = "VEHICULOS DENTRO DEL PARQUEADERO\n\n";

        for (Vehiculo vehiculo : vehiculosDentro) {
            listaVehiculos = listaVehiculos + "Placa: " + vehiculo.getPlaca()
                    + "   Conductor: " + vehiculo.getConductor() + "\n";
        }

        return listaVehiculos;
    }

    private Vehiculo buscarCarro(String numeroPlaca) {
        for (Vehiculo vehiculo : vehiculosDentro) {
            if (vehiculo.getPlaca().equals(numeroPlaca)) {
                return vehiculo;
            }
        }

        return null;
    }

    private void guardarVehiculo(String registro) {
        try {
            FileWriter archivo = new FileWriter("vehiculos.txt", true);
            archivo.write(registro + "\n");
            archivo.close();
        } catch (IOException error) {
            System.out.println("No se pudo guardar vehiculos.txt");
        }
    }

    private void guardarCaja(String registro) {
        try {
            FileWriter archivo = new FileWriter("caja.txt", true);
            archivo.write(registro + "\n");
            archivo.close();
        } catch (IOException error) {
            System.out.println("No se pudo guardar caja.txt");
        }
    }
}
