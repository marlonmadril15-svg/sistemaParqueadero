package parqueadero;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.BorderFactory;

// Pantalla que registra la salida y muestra cuanto debe pagar el carro.
public class VentanaSalida extends JFrame {

    private Parqueadero registroParqueadero;
    private Main ventanaPrincipal;
    private JTextField campoPlaca;
    private JTextField campoHoras;
    private JTextArea areaResultado;

    public VentanaSalida(Parqueadero registroParqueadero, Main ventanaPrincipal) {
        this.registroParqueadero = registroParqueadero;
        this.ventanaPrincipal = ventanaPrincipal;

        setTitle("Parqueadero | Registrar salida");
        setSize(500, 360);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        crearPantalla();
    }

    private void crearPantalla() {
        Color azulPrincipal = new Color(31, 78, 121);
        Color fondoClaro = new Color(242, 247, 252);
        getContentPane().setBackground(fondoClaro);

        JPanel encabezado = new JPanel(new FlowLayout(FlowLayout.LEFT, 18, 12));
        encabezado.setBackground(azulPrincipal);
        JLabel titulo = new JLabel("REGISTRAR SALIDA Y COBRO");
        titulo.setFont(new Font("SansSerif", Font.BOLD, 16));
        titulo.setForeground(Color.WHITE);
        encabezado.add(titulo);

        JPanel datos = new JPanel(new GridLayout(2, 2, 12, 14));
        datos.setBackground(fondoClaro);
        datos.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createTitledBorder("Datos de salida"),
                BorderFactory.createEmptyBorder(14, 16, 14, 16)));

        datos.add(new JLabel("Placa:"));
        campoPlaca = new JTextField();
        datos.add(campoPlaca);

        datos.add(new JLabel("Horas usadas:"));
        campoHoras = new JTextField();
        datos.add(campoHoras);

        JButton botonSalida = new JButton("Sacar carro y cobrar");
        botonSalida.addActionListener(e -> sacarCarro());

        areaResultado = new JTextArea("Escriba las horas. Ejemplo: 2 o 1,5");
        areaResultado.setEditable(false);
        areaResultado.setFont(new Font("SansSerif", Font.PLAIN, 13));
        areaResultado.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JPanel panelBoton = new JPanel();
        panelBoton.setBackground(fondoClaro);
        panelBoton.setBorder(BorderFactory.createEmptyBorder(8, 8, 12, 8));
        panelBoton.add(botonSalida);

        JPanel contenidoCentral = new JPanel(new BorderLayout());
        contenidoCentral.setBackground(fondoClaro);
        contenidoCentral.add(datos, BorderLayout.NORTH);
        contenidoCentral.add(new JScrollPane(areaResultado), BorderLayout.CENTER);

        add(encabezado, BorderLayout.NORTH);
        add(contenidoCentral, BorderLayout.CENTER);
        add(panelBoton, BorderLayout.SOUTH);
    }

    private void sacarCarro() {
        String numeroPlaca = campoPlaca.getText().trim();
        String textoHoras = campoHoras.getText().trim().replace(",", ".");

        if (numeroPlaca.isEmpty() || textoHoras.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Escriba la placa y las horas.");
            return;
        }

        try {
            double horasUsadas = Double.parseDouble(textoHoras);

            if (horasUsadas <= 0) {
                JOptionPane.showMessageDialog(this, "Las horas deben ser mayores que cero.");
                return;
            }

            areaResultado.setText(registroParqueadero.sacarCarro(numeroPlaca, horasUsadas));
            ventanaPrincipal.actualizarCarros();
            campoPlaca.setText("");
            campoHoras.setText("");
        } catch (NumberFormatException error) {
            JOptionPane.showMessageDialog(this, "Las horas deben ser un numero.");
        }
    }
}
