package parqueadero;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.FlowLayout;
import javax.swing.JButton;
import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

// Pantalla para ver los carros que aun no han salido.
public class VentanaCarros extends JFrame {

    private Parqueadero registroParqueadero;
    private JTextArea areaVehiculos;

    public VentanaCarros(Parqueadero registroParqueadero) {
        this.registroParqueadero = registroParqueadero;

        setTitle("Parqueadero | Vehiculos dentro");
        setSize(520, 360);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);

        Color azulPrincipal = new Color(31, 78, 121);
        Color fondoClaro = new Color(242, 247, 252);
        getContentPane().setBackground(fondoClaro);

        JPanel encabezado = new JPanel(new FlowLayout(FlowLayout.LEFT, 18, 12));
        encabezado.setBackground(azulPrincipal);
        JLabel titulo = new JLabel("VEHICULOS ACTUALMENTE DENTRO");
        titulo.setFont(new Font("SansSerif", Font.BOLD, 16));
        titulo.setForeground(Color.WHITE);
        encabezado.add(titulo);

        areaVehiculos = new JTextArea();
        areaVehiculos.setEditable(false);
        areaVehiculos.setFont(new Font("Monospaced", Font.PLAIN, 13));
        areaVehiculos.setBorder(BorderFactory.createEmptyBorder(12, 12, 12, 12));

        JButton botonActualizar = new JButton("Actualizar");
        botonActualizar.addActionListener(e -> actualizarLista());

        JPanel panelBoton = new JPanel();
        panelBoton.setBackground(fondoClaro);
        panelBoton.setBorder(BorderFactory.createEmptyBorder(8, 8, 12, 8));
        panelBoton.add(botonActualizar);

        add(encabezado, BorderLayout.NORTH);
        add(new JScrollPane(areaVehiculos), BorderLayout.CENTER);
        add(panelBoton, BorderLayout.SOUTH);
    }

    public void actualizarLista() {
        areaVehiculos.setText(registroParqueadero.verCarros());
    }
}
