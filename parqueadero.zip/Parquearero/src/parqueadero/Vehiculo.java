package parqueadero;

// Guarda los datos de un carro.
public class Vehiculo {

    private String numeroPlaca;
    private String nombreConductor;

    public Vehiculo(String numeroPlaca, String nombreConductor) {
        this.numeroPlaca = numeroPlaca;
        this.nombreConductor = nombreConductor;
    }

    public String getPlaca() {
        return numeroPlaca;
    }

    public String getConductor() {
        return nombreConductor;
    }
}
